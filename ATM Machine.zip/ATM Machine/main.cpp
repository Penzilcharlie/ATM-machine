#include <iostream>
#include <stdlib.h>

using namespace std;

void sign_in();
void menu();
int balance(int acc_num);
int deposit(int acc_num);
int withdrawal(int acc_num);
void exit();
int acc_balance[10]={700,800,500,1000,120,1400,200,7000,400,900};

int main()
{
  int acc_num, option;
  int charlie = 1;


  sign_in();

   cin >> acc_num;

      if (acc_num >=0 && acc_num <=9)
      {
        system("cls");
      cout << " YOU ARE NOW ONLINE ON YOUR TRUSTED ATM" << endl;
      cout << " ______________________________________" << endl;
      cout << endl;
      }
    else
      {
        system("cls");
        cout << endl;
        cout << "**PLEASE INPUT THE RIGHT ACCOUNT NUMBER**" <<endl;
        cout << endl;
        cout << endl;
        int num;
        cout << "Press #0  --To Exit--" << endl;
        cout << endl;
        cin >> num;
        num=0;
        system("cls");
        main();
      }
      do
        {


      menu();

        cin >> option;

        if (option==1)
         {
          system("cls");
          balance(acc_num);
         }

        else if(option==2)
         {
          system("cls");
          deposit(acc_num);
         }

        else if(option==3)
         {
          system("cls");
          withdrawal(acc_num);

         }

        else if(option==4)
         {
          exit();
         }

        else
         {
          cout << "**PLEASE CHOOSE ONE OF THE OPTIONS ABOVE**" <<endl;
         }
      }

      while(charlie == 1);


    return 0;
}


void menu()
{
   cout << "--Please select your options--" << endl;
   cout << endl;
   cout << endl;
   cout << "1.Balance" << endl;
   cout << endl;
   cout << "2.Deposit" << endl;
   cout << endl;
   cout << "3.Withdraw" << endl;
   cout << endl;
   cout << "4.Exit" << endl;
   cout << endl;

 }


void sign_in()
{
   int acc_num;
   cout << "WELCOME TO YOUR TRUSTED ATM MACHINE" << endl;
   cout << endl;
   cout << "---Please Sign in---" << endl;
   cout << endl;
   cout << "Account Number(0-9) " << endl;
   cout << endl;
}


int balance(int acc_num)
{
  cout << "--Current balance--" << endl;
  cout << endl;
  cout << endl;
  cout << "cash: $" << acc_balance[acc_num] << endl;
  cout << endl;
  cout << endl;
  if (acc_balance[acc_num] < 100)
  {
      cout << "Your current balance is LOW!!" << endl;
  }
  int num;
  cout << "Press #0  --To Exit--" << endl;
  cin >> num;
  num=0;
  system("cls");
}


int deposit(int acc_num)
{
  int deposit;
  cout << "--CASH DEPOSIT--"<< endl;
  cout << endl;
  cout << endl;
  cout << "Enter amount to deposit" << endl;
  cout << "Deposit: ";
  cin >> deposit;
  cout << endl;
  cout << endl;
  if ( deposit >=1 )
  {
    cout << "--Deposit received--" << endl;
    cout << "Current balance: " << acc_balance[acc_num]+deposit << endl;
    cout << endl;
    cout << endl;
  }

  if ( deposit < 1)
  {
    cout << "--Invalid amount--" << endl;
    cout << "Deposit $1 and above"<< endl;
  }

  int num;
  cout << "Press #0  --To Exit--" << endl;
  cin >> num;
  num=0;
  system("cls");

}


int withdrawal(int acc_num)
{
  int withdraw;
  cout << "--CASH WITHDRAWAL--"<< endl;
  cout << endl;
  cout << endl;
  cout << "Enter amount to withdraw" << endl;
  cout << "Amount: ";
  cin >> withdraw;
  cout << endl;
  if ( withdraw > acc_balance[acc_num])
  {
    cout << "**Your balance is insufficient**" << endl;
    cout << "Current balance: $" << acc_balance[acc_num] << endl;
    cout << endl;
    cout << endl;
    cout << "Enter new amount: ";
    cin >> withdraw;
    cout << endl;
  }

  if ( withdraw < acc_balance[acc_num])
  {
    cout << "--Request accepted--" << endl;
    cout << "Current balance: $" << acc_balance[acc_num]-withdraw << endl;
    cout << endl;
    cout << endl;
  }
  else if ( withdraw > acc_balance[acc_num])
  {
      main();
  }

int num;
  cout << "Press #0  --To Exit--" << endl;
  cin >> num;
  num=0;
  system("cls");
}


void exit()
{
  int num;
  system("cls");
  cout << endl;
  cout << endl;
  cout << endl;
  cout << "**Good Bye**" << endl;
  cout << "Press #0  --To Exit--" << endl;
  cin >> num;
  num=0;
  system("cls");
  main();
}

5555444
